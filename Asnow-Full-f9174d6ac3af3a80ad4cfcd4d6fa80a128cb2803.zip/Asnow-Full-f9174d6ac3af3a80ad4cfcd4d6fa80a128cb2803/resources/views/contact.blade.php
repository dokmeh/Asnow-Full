<div class="contact-container">
    <div class="logo-h">
        <img src="img/logo-dark.svg" alt=""/>
    </div>
    <div class="infos">
        <div><div class="inf-title">Tel  | </div><div><a href="call:+982188106290"><b> + 98 </b>2188106290</a></div>
                <div><a href="call:+982188552747"><b> + 98 </b>2188552747</a></div>
        </div>
        <div><div class="inf-title">Fax  | </div><div><a href="fax:+982188701651"><b> + 98 </b>2188701651</a></div></div>
        <div><div class="inf-title">Email  | </div><div><a href="mailto:info@aznow.ir">info@asnow.ir</a></div></div>
        <div><div class="inf-title">Address  | </div><div><a href="#">NO.15 ,4th Alley,<br>Vozara St, Tehran, Iran</a></div></div>
        <div><a class="insta" href="#"><img class="insta" src="img/instagram.svg" alt=""/></a></div>
    </div>
</div>
<div class="map" id="googleMap">

</div>
<script type="text/javascript">
    $(document).ready(function() {
        contact();
    });
</script>